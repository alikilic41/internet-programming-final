<?php

    echo "Bütte görüşmek dileğiyle.";
?>